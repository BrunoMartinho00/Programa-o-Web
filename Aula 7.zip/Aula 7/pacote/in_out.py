def ler_numero():
    pass